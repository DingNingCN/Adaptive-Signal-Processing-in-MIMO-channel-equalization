
function [MSE, MSE2, MSE3, MSE_LS] = channel_est_MIMO_LS_LMS(Ns,Nd,snr_db,L,u,v,w)

% Symbol energy
E = 1;

% Signal-to-noise ratio (SNR) 
snr = exp(snr_db*log(10)/10);
sigma_v_d = sqrt(E*Ns/Nd/snr);

% Channel parameters 
H = complex(randn(Nd,Ns),randn(Nd,Ns))/sqrt(2);

% Training sequence
S = sqrt(E)/sqrt(2)*complex(sign(randi(2,Ns,L)-1.5),sign(randi(2,Ns,L)-1.5));%QPSK调制

% Noise
V_d = sigma_v_d/sqrt(2)*complex(randn(Nd,L),randn(Nd,L));


D = H*S + V_d; %D是接收信号

% LMS Channel Estimation
H_LMS = zeros(Nd,Ns);%Hhat的估计值设为0
H_LMS2 = zeros(Nd,Ns);
H_LMS3 = zeros(Nd,Ns);

R = zeros(Ns,Ns);
P = zeros(Ns,Nd);

for i=1:L
    
H_LMS = H_LMS + 2*u*(D(:,i) - H_LMS*S(:,i))*S(:,i)';%L是一个packet的长度，发送信息是t*L的大小，这里对每列信号都求个error，不断迭代
H_LMS2 = H_LMS2 + 2*v*(D(:,i) - H_LMS2*S(:,i))*S(:,i)';
H_LMS3 = H_LMS3 + 2*w*(D(:,i) - H_LMS3*S(:,i))*S(:,i)';


R = R + S(:,i)*(S(:,i)');
P = P + S(:,i)*(D(:,i)');


end

H_LS = (pinv(R)*P)';


MSE = ((norm(H-H_LMS,'fro'))^2);
MSE2 = ((norm(H-H_LMS2,'fro'))^2);
MSE3 = ((norm(H-H_LMS3,'fro'))^2);
MSE_LS = ((norm(H-H_LS,'fro'))^2);













