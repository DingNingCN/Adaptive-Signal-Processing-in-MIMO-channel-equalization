
function [MSE_LS, MSE_RLS] = channel_est_MIMO_LS_RLS(Ns,Nd,snr_db,L)

% Symbol energy
E = 1;

% Signal-to-noise ratio (SNR) 
snr = exp(snr_db*log(10)/10);
sigma_v_d = sqrt(E*Ns/Nd/snr);

% Channel parameters 
H = complex(randn(Nd,Ns),randn(Nd,Ns))/sqrt(2);

% Training sequence
S = sqrt(E)/sqrt(2)*complex(sign(randi(2,Ns,L)-1.5),sign(randi(2,Ns,L)-1.5));%QPSK调制

% Noise
V_d = sigma_v_d/sqrt(2)*complex(randn(Nd,L),randn(Nd,L));


D = H*S + V_d; %D是接收信号

R = zeros(Ns,Ns);
O = zeros(Ns,Nd);
U = zeros(Nd,Ns);

H_RLS = zeros(Nd,Ns);
P = eye(Ns);


for i=1:L

R = R + S(:,i)*(S(:,i)');
% O = O + S(:,i)*(D(:,i)');
U = U + D(:,i)*(S(:,i)');


K = (S(:,i)'*P)/(1+S(:,i)'*P*S(:,i));
H_RLS = H_RLS + (D(:,i) - H_RLS*S(:,i))*K;
P = P-P*S(:,i)*K;
end

% H_LS = (pinv(R)*O)';
H_LS = U*pinv(R);


MSE_LS = ((norm(H-H_LS,'fro'))^2);
MSE_RLS = ((norm(H-H_RLS,'fro'))^2);













